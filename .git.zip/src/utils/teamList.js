const teamList =
    [
        "TechFin", "SaaS", "ENS", "BIA", "BAO", "MDDC", "HR","Sales","TS"
    ];

module.exports = teamList;